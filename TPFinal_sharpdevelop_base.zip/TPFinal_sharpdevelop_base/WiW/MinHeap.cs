﻿/*
 * Creado por SharpDevelop.
 * Usuario: LEONEL
 * Fecha: 7/11/2024
 * Hora: 08:50
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;
using System.Collections;
using System.Collections.Generic;
	

namespace tpfinal
{
	/// <summary>
	/// Description of MinHeap.
	/// </summary>
	public class MinHeap<T>
	{
		 private List<T> elements;
    private Comparison<T> comparison;

    public MinHeap(Comparison<T> comparison)
    {
        this.comparison = comparison;
        elements = new List<T>();
    }

    public int Count
    {
        get { return elements.Count; }
    }

    public List<T> Elements
    {
        get { return elements; }
    }

    public void Insert(T item)
    {
        elements.Add(item);
        HeapifyUp(elements.Count - 1);
    }

    public T ExtractMin()
    {
        if (elements.Count == 0)
            throw new InvalidOperationException("Heap is empty");

        T min = elements[0];
        elements[0] = elements[elements.Count - 1];
        elements.RemoveAt(elements.Count - 1);
        HeapifyDown(0);

        return min;
    }

    private void HeapifyUp(int index)
    {
        while (index > 0)
        {
            int parentIndex = (index - 1) / 2;
            if (comparison(elements[index], elements[parentIndex]) >= 0)
                break;

            Swap(index, parentIndex);
            index = parentIndex;
        }
    }

    private void HeapifyDown(int index)
    {
        int lastIndex = elements.Count - 1;
        while (index < lastIndex)
        {
            int leftChildIndex = 2 * index + 1;
            int rightChildIndex = 2 * index + 2;
            int smallestIndex = index;

            if (leftChildIndex <= lastIndex && comparison(elements[leftChildIndex], elements[smallestIndex]) < 0)
                smallestIndex = leftChildIndex;

            if (rightChildIndex <= lastIndex && comparison(elements[rightChildIndex], elements[smallestIndex]) < 0)
                smallestIndex = rightChildIndex;

            if (smallestIndex == index)
                break;

            Swap(index, smallestIndex);
            index = smallestIndex;
        }
    }

    private void Swap(int indexA, int indexB)
    {
        T temp = elements[indexA];
        elements[indexA] = elements[indexB];
        elements[indexB] = temp;
    }
	}
}
