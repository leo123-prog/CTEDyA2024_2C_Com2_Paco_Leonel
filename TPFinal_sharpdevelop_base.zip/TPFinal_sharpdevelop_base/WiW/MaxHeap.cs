﻿/*
 * Creado por SharpDevelop.
 * Usuario: LEONEL
 * Fecha: 7/11/2024
 * Hora: 08:40
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;
using System.Collections;
using System.Collections.Generic;

namespace tpfinal
{
	/// <summary>
	/// 
	/// Description of MaxHeap.
	/// </summary>
	public class MaxHeap<T>
	{
		   private List<T> elements;
    private Comparison<T> comparison;

    public MaxHeap(Comparison<T> comparison)
    {
        this.comparison = comparison;
        elements = new List<T>();
    }

    public int Count
    {
        get { return elements.Count; }
    }

    public List<T> Elements
    {
        get { return elements; }
    }

    public void Insert(T item)
    {
        elements.Add(item);
        HeapifyUp(elements.Count - 1);
    }

    public T ExtractMax()
    {
        if (elements.Count == 0)
            throw new InvalidOperationException("Heap is empty");

        T max = elements[0];
        elements[0] = elements[elements.Count - 1];
        elements.RemoveAt(elements.Count - 1);
        HeapifyDown(0);

        return max;
    }

    private void HeapifyUp(int index)
    {
        while (index > 0)
        {
            int parentIndex = (index - 1) / 2;
            if (comparison(elements[index], elements[parentIndex]) <= 0)
                break;

            Swap(index, parentIndex);
            index = parentIndex;
        }
    }

    private void HeapifyDown(int index)
    {
        int lastIndex = elements.Count - 1;
        while (index < lastIndex)
        {
            int leftChildIndex = 2 * index + 1;
            int rightChildIndex = 2 * index + 2;
            int largestIndex = index;

            if (leftChildIndex <= lastIndex && comparison(elements[leftChildIndex], elements[largestIndex]) > 0)
                largestIndex = leftChildIndex;

            if (rightChildIndex <= lastIndex && comparison(elements[rightChildIndex], elements[largestIndex]) > 0)
                largestIndex = rightChildIndex;

            if (largestIndex == index)
                break;

            Swap(index, largestIndex);
            index = largestIndex;
        }
    }

    private void Swap(int indexA, int indexB)
    {
        T temp = elements[indexA];
        elements[indexA] = elements[indexB];
        elements[indexB] = temp;
    }
	}
}
