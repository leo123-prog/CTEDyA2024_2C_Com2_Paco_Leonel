﻿/*
 * Creado por SharpDevelop.
 * Usuario: LEONEL
 * Fecha: 7/11/2024
 * Hora: 08:40
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;
using System.Collections;
using System.Collections.Generic;

namespace tpfinal
{
public class MaxHeap<T> where T:Proceso
{
    private List<T> elementos;

    public MaxHeap()
    {
        elementos = new List<T>();
    }

    public int Count
    {
        get { return elementos.Count; }
    }

    public List<T> Elementos
    {
        get { return elementos; }
    }

    public void Insertar(T item)
    {
        elementos.Add(item);
        filtradoHaciaArriba(elementos.Count - 1);
    }

    public T ExtraerMax()
    {
        if (elementos.Count == 0)
            throw new InvalidOperationException("El heap está vacío.");

        T max = elementos[0];
        elementos[0] = elementos[elementos.Count - 1];
        elementos.RemoveAt(elementos.Count - 1);
        filtradoHaciaAbajo(0);

        return max;
    }

    private void filtradoHaciaArriba(int posicionNodo)
    {
        while (posicionNodo > 0)
        {
            int padrePosicion = (posicionNodo - 1) / 2;

            // Comparamos el nodo actual con su padre usando lógica explícita
            if (!EsMayor(elementos[posicionNodo], elementos[padrePosicion]))
                break;

            intercambio(posicionNodo, padrePosicion);
            posicionNodo = padrePosicion;
        }
    }
     
    private void filtradoHaciaAbajo(int posicionNodo)
    {
        int UltimaPosicion = elementos.Count - 1;
        while (posicionNodo < UltimaPosicion)
        {
            int hijoIzquierdoPosicion = 2 * posicionNodo + 1;//Calculos para obtener hijos de una posicion dada
            int hijoDerechoPosicion = 2 * posicionNodo + 2;  //en un heap implementado en una lista dinamica.
            int masGrandePosicion = posicionNodo;

            if (hijoIzquierdoPosicion <= UltimaPosicion &&
                EsMayor(elementos[hijoIzquierdoPosicion], elementos[masGrandePosicion]))
                masGrandePosicion = hijoIzquierdoPosicion;

            if (hijoDerechoPosicion <= UltimaPosicion &&
                EsMayor(elementos[hijoDerechoPosicion], elementos[masGrandePosicion]))
                masGrandePosicion = hijoDerechoPosicion;

            if (masGrandePosicion == posicionNodo)
                break;

            intercambio(posicionNodo, masGrandePosicion);
            posicionNodo = masGrandePosicion;
        }
    }

    private void intercambio(int indexA, int indexB)
    {
        T temp = elementos[indexA];
        elementos[indexA] = elementos[indexB];
        elementos[indexB] = temp;
    }

    // Lógica explícita para comparar elementos
    private bool EsMayor(T item1, T item2)
    {
        
        int valor1 = ObtenerPrioridad(item1);
        int valor2 = ObtenerPrioridad(item2);

        return valor1 > valor2;
    }

    private int ObtenerPrioridad(T item)
    {
        //Ya que utilizamos where T: Proceso. Podemos acceder al 
        //atributo de Proceso. Ya que le indica a la clase que tome a T
        //en principio como un objeto del tipo "Proceso"
       	return item.prioridad;
       
    }
}

}
