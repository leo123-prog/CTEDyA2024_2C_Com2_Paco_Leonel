﻿using System;
using System.Collections.Generic;
using System.Collections;

namespace tpfinal
{

	[Serializable]
	public class Proceso
	{
		public string nombre { get; set; } // String of symbols
       
		public int prioridad { get; set; }

        public int tiempo { get; set; }
       
        
        public Proceso(string nombre, int tiempo, int prioridad)
		{
			this.nombre = nombre;
			this.tiempo = tiempo;
			this.prioridad = prioridad;
        }
        
        public int getTiempo(){
        	
        	return tiempo;
        }



		public override string ToString()
		{
			if (nombre != null)
			{

				return "\n Nombre Del Proceso:" + nombre + "\n Tiempo" +
					": " + tiempo+"\n Prioridad: " + prioridad + "\n"; ;

			}
			else
			{

				return "";
			}
		}

	}
}