﻿
using System;
using System.Collections.Generic;
using System.Numerics;
using tp1;

namespace tpfinal
{
public class Estrategia
{
    private MinHeap<Proceso> minHeapSJF;
    private MaxHeap<Proceso> maxHeapPriority;

    public Estrategia()
    {
       // las clases MinHeap y MaxHeap gestionan la comparación internamente
        minHeapSJF = new MinHeap<Proceso>();  // Ordenará por tiempo de CPU
        maxHeapPriority = new MaxHeap<Proceso>();  // Ordenará por prioridad
    }

    // Algoritmo Shortest Job First (SJF)
    public void ShortestJobFirst(List<Proceso> datos, List<Proceso> collected)
    {
        foreach (Proceso proceso in datos)
        {
        	
            minHeapSJF.Insertar(proceso);
        }

        while (minHeapSJF.Count > 0)
        {
            collected.Add(minHeapSJF.ExtraerMin());
        }
    }

    // Algoritmo Preemptive Priority
    public void PreemptivePriority(List<Proceso> datos, List<Proceso> collected)
    {
        foreach (Proceso proceso in datos)
        {
            maxHeapPriority.Insertar(proceso);
        }

        while (maxHeapPriority.Count > 0)
        {
            collected.Add(maxHeapPriority.ExtraerMax());
        }
    }

    // Consulta 1: Mostrar las hojas de las heaps
    public string Consulta1(List<Proceso> datos)
    {
        // Insertar todos los procesos en las heaps sin modificar las originales
        foreach (var proceso in datos)
        {
            minHeapSJF.Insertar(proceso);
            maxHeapPriority.Insertar(proceso);
        }

        // Acceso a las hojas: las hojas están al final del heap
        string result = "Hojas del MinHeap (SJF):  ";
        for (int i = (minHeapSJF.Count) / 2  ; i < minHeapSJF.Count; i++)
        {
            result += minHeapSJF.Elementos[i].ToString() + ", ";
        }

        result += "\n\n\nHojas de MaxHeap (Priority):  ";
        for (int i = (maxHeapPriority.Count - 1) / 2 ; i < maxHeapPriority.Count; i++)
        {
            result += maxHeapPriority.Elementos[i].ToString() + ", ";
        }

        return result.TrimEnd(',', ' ');
    }

    // Consulta 2: Mostrar la altura de las heaps
    public string Consulta2(List<Proceso> datos)
    {
        // Insertar todos los procesos en las heaps
        foreach (var proceso in datos)
        {
            minHeapSJF.Insertar(proceso);
            maxHeapPriority.Insertar(proceso);
        }

        // Calcula las alturas de las heaps
        int alturaMinHeap = (int)Math.Floor(Math.Log(minHeapSJF.Count + 1) / Math.Log(2));
        int alturaMaxHeap = (int)Math.Floor(Math.Log(maxHeapPriority.Count + 1) / Math.Log(2));

        return "Altura de MinHeap (SJF): " + alturaMinHeap +
               "\nAltura de MaxHeap (Priority): " + alturaMaxHeap;
    }

    // Consulta 3: Mostrar los datos en los niveles de las heaps
    public string Consulta3(List<Proceso> datos)
    {
        // Insertar todos los procesos en las heaps
        foreach (var proceso in datos)
        {
            minHeapSJF.Insertar(proceso);
            maxHeapPriority.Insertar(proceso);
        }

        // Retornar los datos con sus niveles
        string result = "Datos en MinHeap (SJF):\n";
        for (int i = 0; i < minHeapSJF.Count; i++)
        {
            int nivel = (int)Math.Floor(Math.Log(i + 1) / Math.Log(2)); // Calcular el nivel del nodo
            result += "Nivel " + nivel + ": " + minHeapSJF.Elementos[i].ToString() + "\n";
        }

        result += "\nDatos en MaxHeap (Priority):\n";
        for (int i = 0; i < maxHeapPriority.Count; i++)
        {
            int nivel = (int)Math.Floor(Math.Log(i + 1) / Math.Log(2)); // Calcular el nivel del nodo
            result += "\n Nivel:" + nivel + ": " + maxHeapPriority.Elementos[i].ToString() + "\n";
        }

        return result;
    }
}
}