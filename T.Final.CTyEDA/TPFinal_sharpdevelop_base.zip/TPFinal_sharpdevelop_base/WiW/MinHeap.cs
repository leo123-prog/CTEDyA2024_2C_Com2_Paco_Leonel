﻿/*
 * Creado por SharpDevelop.
 * Usuario: LEONEL
 * Fecha: 7/11/2024
 * Hora: 08:50
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;
using System.Collections;
using System.Collections.Generic;
	

namespace tpfinal
{
public class MinHeap<T> where T:Proceso
{
    private List<T> elementos;

    public MinHeap()
    {
        elementos = new List<T>();
    }

    public int Count
    {
        get { return elementos.Count; }
    }

    public List<T> Elementos
    {
        get { return elementos; }
    }

    public void Insertar(T item)
    {
        elementos.Add(item);
        filtradoHaciaArriba(elementos.Count - 1); 
    }

    public T ExtraerMin()
    {
        if (elementos.Count == 0)
            throw new InvalidOperationException("El heap está vacío.");

        T min = elementos[0];
        elementos[0] = elementos[elementos.Count - 1];
        elementos.RemoveAt(elementos.Count - 1);
        filtradoHaciaAbajo(0);

        return min;
    }

    private void filtradoHaciaArriba(int posicionNodo)
    {
        while (posicionNodo > 0)
        {
            int padrePosicion = (posicionNodo - 1) / 2;

            // Comparamos el nodo actual con su padre usando lógica explícita
            if (!EsMenor(elementos[posicionNodo], elementos[padrePosicion]))
                break;

            intercambio(posicionNodo, padrePosicion);
            posicionNodo = padrePosicion;
        }
    }

    private void filtradoHaciaAbajo(int posicionNodo)
	{
	    int ultimaPosicion = elementos.Count - 1;
	    
	    
	    //
	    while (posicionNodo < ultimaPosicion)
	    {
	        int hijoIzquierdoPosicion = 2 * posicionNodo + 1; // Índice del hijo izquierdo
	        int hijoDerechoPosicion = 2 * posicionNodo + 2;  // Índice del hijo derecho
	        int masPequeñoPosicion = posicionNodo;          // Por defecto, asumimos que el nodo actual es el más pequeño
	
	        // Verificar si el hijo izquierdo es menor
	        if (hijoIzquierdoPosicion <= ultimaPosicion &&
	            EsMenor(elementos[hijoIzquierdoPosicion], elementos[masPequeñoPosicion]))
	        {
	            masPequeñoPosicion = hijoIzquierdoPosicion;
	        }
	
	        // Verificar si el hijo derecho es menor
	        if (hijoDerechoPosicion <= ultimaPosicion &&
	            EsMenor(elementos[hijoDerechoPosicion], elementos[masPequeñoPosicion]))
	        {
	            masPequeñoPosicion = hijoDerechoPosicion;
	        }
	
	        // Si el nodo actual es más pequeño que ambos hijos, termina el bucle
	        if (masPequeñoPosicion == posicionNodo)
	        {
	            break;
	        }
	
	        // Intercambiar el nodo actual con el hijo más pequeño
	        intercambio(posicionNodo, masPequeñoPosicion);
	
	        // Actualizar la posición del nodo actual
	        posicionNodo = masPequeñoPosicion;
	    }
	}


    private void intercambio(int indexA, int indexB)
    {
        T temp = elementos[indexA];
        elementos[indexA] = elementos[indexB];
        elementos[indexB] = temp;
    }

    // Lógica explícita para comparar elementos
    private bool EsMenor(T item1, T item2)
    {
     
        int valor1 = ObtenerTiempo(item1);
        int valor2 = ObtenerTiempo(item2);

        return valor1 <= valor2;
    }

    private int ObtenerTiempo(T item)
    {
         //Ya que utilizamos where T: Proceso. Podemos acceder al 
        //atributo de Proceso. Ya que le indica a la clase que tome a T
        //en principio como un objeto del tipo "Proceso"
        	return item.tiempo; 
    }
}

}
