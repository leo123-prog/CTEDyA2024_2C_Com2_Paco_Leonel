﻿
using System;
using System.Collections.Generic;
using System.Numerics;
using tp1;

namespace tpfinal
{

    public class Estrategia
    {
    	 private MinHeap<Proceso> minHeapSJF;
    private MaxHeap<Proceso> maxHeapPriority;

    public Estrategia()
    {
        // Ordenar por menor tiempo de CPU para Shortest Job First
        minHeapSJF = new MinHeap<Proceso>((p1, p2) => p1.tiempo.CompareTo(p2.tiempo));

        // Ordenar por mayor prioridad para Preemptive Priority
        maxHeapPriority = new MaxHeap<Proceso>((p1, p2) => p2.prioridad.CompareTo(p1.prioridad));
    }

    public void ShortestJobFirst(List<Proceso> datos, List<Proceso> collected)
    {
        // Copia de la heap original para las consultas
        List<Proceso> copiaMinHeap = new List<Proceso>();

        foreach (Proceso proceso in datos)
        {
            minHeapSJF.Insert(proceso);
        }

        // Copiar los elementos a la lista auxiliar antes de vaciar la heap
        while (minHeapSJF.Count > 0)
        {
            Proceso proceso = minHeapSJF.ExtractMin();
            collected.Add(proceso);
            copiaMinHeap.Add(proceso);  // Guardamos el proceso para las consultas
        }

        // Ahora las consultas pueden operar sobre copiaMinHeap
    }

    public void PreemptivePriority(List<Proceso> datos, List<Proceso> collected)
    {
        // Copia de la heap original para las consultas
        List<Proceso> copiaMaxHeap = new List<Proceso>();

        foreach (Proceso proceso in datos)
        {
            maxHeapPriority.Insert(proceso);
        }

        // Copiar los elementos a la lista auxiliar antes de vaciar la heap
        while (maxHeapPriority.Count > 0)
        {
            Proceso proceso = maxHeapPriority.ExtractMax();
            collected.Add(proceso);
            copiaMaxHeap.Add(proceso);  // Guardamos el proceso para las consultas
        }

        // Ahora las consultas pueden operar sobre copiaMaxHeap
    }

   public string Consulta1(List<Proceso> datos)
{
    // Crea copias de las heaps para no vaciarlas
    MinHeap<Proceso> minHeapCopy = new MinHeap<Proceso>((p1, p2) => p1.tiempo.CompareTo(p2.tiempo));
    MaxHeap<Proceso> maxHeapCopy = new MaxHeap<Proceso>((p1, p2) => p2.prioridad.CompareTo(p1.prioridad));

    foreach (var proceso in datos)
    {
        minHeapCopy.Insert(proceso);
        maxHeapCopy.Insert(proceso);
    }

    // Ahora puedes acceder a las hojas sin que las heaps originales estén vacías
    string result = "Hojas de MinHeap (SJF): ";
    for (int i = (minHeapCopy.Count - 1) / 2 + 1; i < minHeapCopy.Count; i++)
    {
        result += minHeapCopy.Elements[i].ToString() + ", ";
    }

    result += "\nHojas de MaxHeap (Priority): ";
    for (int i = (maxHeapCopy.Count - 1) / 2 + 1; i < maxHeapCopy.Count; i++)
    {
        result += maxHeapCopy.Elements[i].ToString() + ", ";
    }

    return result.TrimEnd(',', ' ');
}

public string Consulta2(List<Proceso> datos)
{
    // Crea copias de las heaps
    MinHeap<Proceso> minHeapCopy = new MinHeap<Proceso>((p1, p2) => p1.tiempo.CompareTo(p2.tiempo));
    MaxHeap<Proceso> maxHeapCopy = new MaxHeap<Proceso>((p1, p2) => p2.prioridad.CompareTo(p1.prioridad));

    foreach (var proceso in datos)
    {
        minHeapCopy.Insert(proceso);
        maxHeapCopy.Insert(proceso);
    }

    // Calcula las alturas de las heaps
    int alturaMinHeap = (int)Math.Floor(Math.Log(minHeapCopy.Count + 1) / Math.Log(2));
    int alturaMaxHeap = (int)Math.Floor(Math.Log(maxHeapCopy.Count + 1) / Math.Log(2));

    return "Altura de MinHeap (SJF): " + alturaMinHeap +
           "\nAltura de MaxHeap (Priority): " + alturaMaxHeap;
}

public string Consulta3(List<Proceso> datos)
{
    // Crea copias de las heaps
    MinHeap<Proceso> minHeapCopy = new MinHeap<Proceso>((p1, p2) => p1.tiempo.CompareTo(p2.tiempo));
    MaxHeap<Proceso> maxHeapCopy = new MaxHeap<Proceso>((p1, p2) => p2.prioridad.CompareTo(p1.prioridad));

    foreach (var proceso in datos)
    {
        minHeapCopy.Insert(proceso);
        maxHeapCopy.Insert(proceso);
    }

    // Retorna los datos con sus niveles
    string result = "Datos en MinHeap (SJF):\n";
    for (int i = 0; i < minHeapCopy.Count; i++)
    {
        int nivel = (int)Math.Floor(Math.Log(i + 1) / Math.Log(2));
        result += "Nivel " + nivel + ": " + minHeapCopy.Elements[i].ToString() + "\n";
    }

    result += "\nDatos en MaxHeap (Priority):\n";
    for (int i = 0; i < maxHeapCopy.Count; i++)
    {
        int nivel = (int)Math.Floor(Math.Log(i + 1) / Math.Log(2));
        result += "Nivel " + nivel + ": " + maxHeapCopy.Elements[i].ToString() + "\n";
    }

    return result;
     }

    }
}